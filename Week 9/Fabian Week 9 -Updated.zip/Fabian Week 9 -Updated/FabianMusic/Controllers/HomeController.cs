﻿using FabianMusic.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace FabianMusic.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }
        public IActionResult FAQ()
        {
            return View();
        }

        /* public ViewResult SetSessionVariables()
             {
                 /*string fabian = HttpContext.Session.GetString("FirstName");
                 string abarca = HttpContext.Session.GetString("LastName");
                 string IT2030 = HttpContext.Session.GetString("Course");
                 int num = HttpContext.Session.GetInt32("FavNum");*/

        /*            HttpContext.Session.SetString("FirstName", "Fabian");
                    HttpContext.Session.SetString("LastName", "Abarca");
                    HttpContext.Session.SetString("Course", "IT2030");
                    HttpContext.Session.SetInt32("FavNum", 33);


                    return View();
                }

       /*     public ViewResult ClearSessionVariables()
                {
                    HttpContext.Session.Remove("FirstName");
                    HttpContext.Session.Remove("LastName");
                    HttpContext.Session.Remove("Course");
                    HttpContext.Session.Remove("FavNum");

                    return View();

                }

        /*    public IActionResult Tools()
            {
                return View();
            } */

        //updated solution

        [HttpGet]
        public IActionResult Tools(MySession sess_name)
        {
            HttpContext.Session.GetString("FirstName");
            HttpContext.Session.GetString("LastName");
            HttpContext.Session.GetString("Course");
            HttpContext.Session.GetString("FavNum");
          
            return View(sess_name);
        }

        [HttpPost]
        public IActionResult Tools()
        {
            MySession variable = new MySession()
            { FirstName = "Fabian",
              LastName = "Abarca",
              Course = "IT2030",
              FavNum = 33
            };

             HttpContext.Session.SetString("FirstName", variable.FirstName);
              HttpContext.Session.SetString("LastName", variable.LastName);
              HttpContext.Session.SetString("Course", variable.Course);
               HttpContext.Session.SetInt32("FavNum", variable.FavNum);

              return View("Tools", variable);
          }

        public IActionResult ClearSessionVariables()
        {

            HttpContext.Session.Remove("FirstName");
            HttpContext.Session.Remove("LastName");
            HttpContext.Session.Remove("Course");
            HttpContext.Session.Remove("FavNum");

            return View("Tools");

        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
}